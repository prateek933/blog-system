<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\RegistrationController;
use App\Http\Controllers\SessionController;
use App\Http\Controllers\PostController;
use App\Http\Controllers\UpdatePasswordController;
use App\Http\Controllers\ForgotPasswordController;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


Route::get('/', [HomeController::class, 'index'])->name('dashboard');
Route::get('/search', [HomeController::class, 'search'])->name('search');

Route::group(['middleware' => ['web'], 'prefix' => '/user'], function () {
    // Register User
    Route::get('/register', [RegistrationController::class, 'show'])->name('user.register.index');
    Route::post('/register', [RegistrationController::class, 'create'])->name('user.register.create');

    // login and logout user
    Route::get('/login', [SessionController::class, 'show'])->name('user.session.index');
    Route::post('/login', [SessionController::class, 'create'])->name('user.session.create');
    Route::get('/logout', [SessionController::class, 'destroy'])->name('user.session.destroy');

    // store post comments
    Route::post('store/comments', [PostController::class, 'storeComments'])->name('post.comment.store');

    // delete post
    Route::get('/delete/{id}', [PostController::class, 'deletePost'])->name('user.post.delete');

    // view post with comments
    Route::get('/view/post/{id}', [HomeController::class, 'showPost'])->name('view.post');

    // update password
    Route::get('/update-password', [UpdatePasswordController::class, 'index'])->name('user.password.update.index');
    Route::post('/update-password', [UpdatePasswordController::class, 'store'])->name('user.password.update');

    // forgot-password
    Route::get('/forgot-password', [ForgotPasswordController::class, 'index'])->name('user.password.forgot.index');
    Route::post('/forgot-password', [ForgotPasswordController::class, 'store'])->name('user.password.forgot');
    Route::get('/reset-password/{email}', [ForgotPasswordController::class, 'showResetPassword'])->name('user.mail.reset.password');
    Route::post('/reset-password', [ForgotPasswordController::class, 'resetPassword'])->name('user.reset.password');




    Route::group(['middleware' => ['user']], function() {
        // create and manage posts
        Route::get('/posts', [PostController::class, 'index'])->name('user.posts.index');
        Route::post('/posts', [PostController::class, 'store'])->name('user.post.store');
    });
});