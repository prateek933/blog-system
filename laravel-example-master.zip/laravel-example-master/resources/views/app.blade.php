<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>@yield('page_title')</title>

        {{-- all styles --}}
        @include('layout.styles')
    </head>
    <body>
        {{-- main app --}}
        <div id="root">
            {{-- header --}}
            @section('header')
                @include('layout.header.index')
            @show

            <div class="container my-5">
                @if(Session::has('message'))
                    <p class="alert alert-info">{{ Session::get('message') }}</p>
                @endif

                @yield('content-wrapper')
            </div>
        </div>

        {{-- footer --}}
        @section('footer')
            @include('layout.footer.index')
        @show

        {{-- all scripts --}}
        @include('layout.scripts')
    </body>
</html>
