<header class="p-3 bg-dark text-white">
    <div class="container">
      <div class="d-flex flex-wrap align-items-center justify-content-center justify-content-lg-start">
        <a href="/" class="d-flex align-items-center mb-2 mb-lg-0 text-white text-decoration-none">
          <svg class="bi me-2" width="40" height="32" role="img" aria-label="Bootstrap"><use xlink:href="#bootstrap"></use></svg>
        </a>

        @guest
          <ul class="nav col-12 col-lg-auto me-lg-auto mb-2 justify-content-center mb-md-0">
            <li><a href="{{ route('dashboard') }}" class="nav-link px-2 text-secondary">Home</a></li>
          </ul>

          <div class="text-end">
            <a class="btn btn-outline-light me-2" href="{{ route('user.session.index') }}">Login</a>

            <a class="btn btn-warning" href="{{ route('user.register.index') }}">Signup</a>
          </div>
        @endguest

        @auth
          <ul class="nav col-12 col-lg-auto me-lg-auto mb-2 justify-content-center mb-md-0">
            <li><a href="{{ route('dashboard') }}" class="nav-link px-2 text-secondary">Home</a></li>
            <li><a href="{{ route('user.posts.index') }}" class="nav-link px-2 text-white">Manage Posts</a></li>
            <li><a href="{{ route('user.password.update.index') }}" class="nav-link px-2 text-white">Change password</a></li>
          </ul>

          <div>
            <i class="fa fa-user-o" aria-hidden="true"></i>
            <a href="#" class="text-white mr-1"
              style="margin-right: 15px;
              text-decoration: none"
            >
              {{ auth()->user()->username }}
            </a>

            <a class="btn btn-outline-light me-2" href="{{ route('user.session.destroy') }}">Logout</a>
          </div>
        @endauth
      </div>
    </div>
  </header>