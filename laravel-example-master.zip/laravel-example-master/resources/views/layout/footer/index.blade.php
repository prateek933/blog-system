<!-- Footer -->
<footer
        class="text-center text-lg-start text-white"
        style="background-color: #1c2331"
        >
  <!-- Section: Social media -->
  <section
            class="d-flex justify-content-between p-4"
            style="background-color: #6351ce"
            >
    <!-- Left -->
    <div class="me-5">
      <span>Get connected with us on social networks:</span>
    </div>
    <!-- Left -->

    <!-- Right -->
    <div>
      <a href="facebook" class="text-white me-4">
        <i class="fa fa-facebook-square" aria-hidden="true"></i>
      </a>

      <a href="twitter" class="text-white me-4">
        <i class="fa fa-twitter-square" aria-hidden="true"></i>
      </a>

      <a href="google" class="text-white me-4">
        <i class="fa fa-google" aria-hidden="true"></i>
      </a>

      <a href="instagram" class="text-white me-4">
        <i class="fa fa-instagram" aria-hidden="true"></i>
      </a>

      <a href="linkedin" class="text-white me-4">
        <i class="fa fa-linkedin-square" aria-hidden="true"></i>
      </a>

      <a href="github" class="text-white me-4">
        <i class="fa fa-github-square" aria-hidden="true"></i>
      </a>
    </div>
    <!-- Right -->
  </section>
  <!-- Section: Social media -->

  <!-- Section: Links  -->
  <section class="">
    <div class="container text-center text-md-start mt-5">
      <!-- Grid row -->
      <div class="row mt-3">
        <!-- Grid column -->
        <div class="col-md-3 col-lg-4 col-xl-3 mx-auto mb-4">
          <!-- Content -->
          <h6 class="text-uppercase fw-bold">Blogger Post</h6>
          <hr
              class="mb-4 mt-0 d-inline-block mx-auto"
              style="width: 60px; background-color: #7c4dff; height: 2px"
              />
          <p>
            Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.
          </p>
        </div>
        <!-- Grid column -->

        <!-- Grid column -->
        <div class="col-md-2 col-lg-2 col-xl-2 mx-auto mb-4">
          <!-- Links -->
          <h6 class="text-uppercase fw-bold">Latest Posts</h6>
          <hr
              class="mb-4 mt-0 d-inline-block mx-auto"
              style="width: 60px; background-color: #7c4dff; height: 2px"
              />

          @if(isset($posts) && count($posts) <= 6)
            @foreach($posts as $post)
              <p>
                <a href='' class="text-white">{{ $post->title}}</a>
              </p>
            @endforeach
          @endif
        </div>
        <!-- Grid column -->

        <!-- Grid column -->
        <div class="col-md-3 col-lg-2 col-xl-2 mx-auto mb-4">
          <!-- Links -->
          <h6 class="text-uppercase fw-bold">Technologies used</h6>
          <hr
              class="mb-4 mt-0 d-inline-block mx-auto"
              style="width: 60px; background-color: #7c4dff; height: 2px"
              />
          <p>
            <a href="#laravel" class="text-white">Laravel v8.83.1</a>
          </p>
          <p>
            <a href="#html" class="text-white">HTML</a>
          </p>
          <p>
            <a href="#css" class="text-white">CSS</a>
          </p>
          <p>
            <a href="#javascript" class="text-white">Javascript</a>
          </p>
          <p>
            <a href="#bootstrap" class="text-white">Bootstrap</a>
          </p>
        </div>
        <!-- Grid column -->

        <!-- Grid column -->
        <div class="col-md-4 col-lg-3 col-xl-3 mx-auto mb-md-0 mb-4">
          <!-- Links -->
          <h6 class="text-uppercase fw-bold">Contact</h6>
          <hr
              class="mb-4 mt-0 d-inline-block mx-auto"
              style="width: 60px; background-color: #7c4dff; height: 2px"
              />
          <p><i class="fa fa-home" aria-hidden="true"></i>India</p>
          <p><i class="fa fa-envelope" aria-hidden="true"></i>prateeksrivastava933@gmail.com</p>
          <p><i class="fa fa-mobile" aria-hidden="true"></i>+91 8545846475</p>
        </div>
        <!-- Grid column -->

      </div>
      <!-- Grid row -->
    </div>
  </section>
  <!-- Section: Links  -->

</footer>
<!-- Footer -->
