@extends('app')

@section('page_title', 'Recover your password')

@section('content-wrapper')

<h3>Recover your password</h3>

<form method="post" action="{{ route('user.password.forgot') }}">
    @csrf
    
    <div class="mb-3">
        <label for="Email" class="form-label">Email address</label>
        <input type="email" class="form-control" name="email">

        @error('email')
            <div class="error">{{ $message }}</div>
        @enderror
    </div>

    <button type="submit" class="btn btn-outline-warning">Submit</button>
</form>

@endsection