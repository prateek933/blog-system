@extends('app')

@section('page_title', 'Register your account')

@section('content-wrapper')

<form method="post" action="{{ route('user.register.create') }}">
    @csrf
    <div class="mb-3">
        <label for="username" class="form-label">Username</label>
        <input type="text" class="form-control" name="username" value="{{ old('username') }}">

        @error('username')
            <div class="error danger">{{ $message }}</div>
        @enderror
    </div>
    <div class="mb-3">
        <label for="Email" class="form-label">Email address</label>
        <input type="email" class="form-control" name="email" value="{{ old('email') }}">

        @error('email')
            <div class="error danger">{{ $message }}</div>
        @enderror
    </div>

    <div class="mb-3">
        <label for="Password" class="form-label">Password</label>
        <input type="password" class="form-control" name="password">

        @error('password')
            <div class="error danger">{{ $message }}</div>
        @enderror
    </div>

    <button type="submit" class="p-2 btn btn-outline-warning">Submit</button>
</form>

@endsection