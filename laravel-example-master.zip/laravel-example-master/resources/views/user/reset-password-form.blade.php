@extends('app')

@section('page_title', 'Reset your password')

@section('content-wrapper')

<h3>Recover your password</h3>

<form method="post" action="{{ route('user.reset.password') }}">
    @csrf

    <div class="mb-3">
        <label for="Password" class="form-label">New password</label>
        <input type="password" class="form-control" name="new_password">

        @error('new_password')
            <div class="error">{{ $message }}</div>
        @enderror
    </div>

    <input type="hidden" name="email" value="{{ request('email') }}">

    <button type="submit" class="btn btn-outline-warning">Submit</button>
</form>

@endsection