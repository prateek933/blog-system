@extends('app')

@section('page_title', 'Update password')

@section('content-wrapper')

<h3>Update Password</h3>

<form method="post" action="{{ route('user.password.update') }}">
    @csrf

     <div class="mb-3">
        <label for="email" class="form-label">Email</label>
        <input type="email" class="form-control" name="email" disabled value="{{ auth()->user()->email }}">

        @error('email')
            <div class="error">{{ $message }}</div>
        @enderror
    </div>

    <div class="mb-3">
        <label for="Password" class="form-label">Old password</label>
        <input type="password" class="form-control" name="old_password">

        @error('old_password')
            <div class="error">{{ $message }}</div>
        @enderror
    </div>

   <div class="mb-3">
        <label for="Password" class="form-label">New password</label>
        <input type="password" class="form-control" name="new_password">

        @error('new_password')
            <div class="error">{{ $message }}</div>
        @enderror
    </div>

    <button type="submit" class="btn btn-outline-warning">Submit</button>
</form>

@endsection