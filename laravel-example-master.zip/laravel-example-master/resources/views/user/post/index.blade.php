@extends('app')

@section('page_title', 'Manage Posts')

@section('content-wrapper')

<div class="row justify-content-center">
    <div class="col-md-8">
        <div class="card">
            <div class="card-header">Create Post</div>
            <div class="card-body">
                <form method="post" action="{{ route('user.post.store') }}">
                    @csrf
                    <div class="mb-3">
                        <input type="text" class="form-control" name="title_name" placeholder="Enter title">

                        @if ($errors->has('title_name'))
                            <span class="text-danger">{{ $errors->first('<title></title>') }}</span>
                        @endif
                    </div>

                    <div class="mb-3">
                        <textarea class="form-control" name="content" placeholder="Enter content"></textarea>

                        @if ($errors->has('content'))
                            <span class="text-danger">{{ $errors->first('content') }}</span>
                        @endif
                    </div>

                    <div class="mb-3">
                        <input class="form-control" type="text" name="tags">

                        @if ($errors->has('tags'))
                            <span class="text-danger">{{ $errors->first('tags') }}</span>
                        @endif

                        <label>
                            <strong>Note: </strong>
                            <i>Add comma separated values for different tags.</i>
                        </label>
                    </div>

                    <div class="d-grid">
                        <button class="btn btn-info btn-submit">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="col-md-8 mt-5">
        <h3>List of posts</h3>
        <table class="table table-hover">
            <thead>
                <tr class="table-light">
                    <th>#</th>
                    <th>Title</th>
                    <th>Description</th>
                    <th>Posted At</th>
                </tr>
            </thead>

            <tbody>
                @foreach($posts as $key => $post)
                    <tr class="table-light">
                        <th scope="row">{{ $key+1 }}</th>

                        <td>{{ $post->title }}</td>
                        <td>{{ $post->description }}</td>
                        <td>{{ $post->created_at }}</td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</div>

<div class="d-flex justify-content-center">
    {!! $posts->links() !!}
</div>

@endsection