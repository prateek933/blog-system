@extends('app')

@section('page_title', 'Blogger Post')

@section('content-wrapper')

<div class="container mt-5">
    <div class="row">
      <div class="col-12">
        <article class="blog-card">
          <div class="blog-card__info" style="border-radius: 5px;">
            <h5>{{ $post->title }}</h5>

            <p>
              <a href="#" class="icon-link mr-3"><i class="fa fa-pencil-square-o"></i> {{ $post->author }}</a>
            </p>

            <p>
              {{ $post->description }}
            </p>

            <p class="mt-2">
              Posted on: {{ $post->created_at->format('m/d/Y')  }}
            </p>

            @php
              $tags = explode(',', $post->tagnames);
            @endphp

            <p class="text-end">
              <a href="#"  class="icon-link"><i class="fa fa-comments-o"></i> {{ $post->getCommentCounts() }}</a>

              @foreach($tags as $tag)
                <span class="badge rounded-pill bg-warning text-dark">
                  {{ trim($tag) }}
                </span>
              @endforeach
            </p>

          </div>

          @include('home.post-comments')

        </article>
      </div>
    </div>
  </div>

@endsection