@extends('app')

@section('page_title', 'Homepage')

@section('content-wrapper')

@if(empty($posts->all()))
    <h2 class="text-center">No posts Found</h2>
@else
    <!-- search by tags -->
    <form method="get" action="{{ route('search') }}" class="col-12 col-lg-auto mb-3 mb-lg-0 me-lg-3">
        <input type="search" class="form-control form-control-dark" name="search" placeholder="Search...">
        <input type="submit" hidden>
    </form>

    @include('home.posts')
@endif

@endsection