<div class="row d-flex">
  <div class="col-md-8 col-lg-6">
      <div class="card-body p-4">

        @auth
          <div class="form-outline mb-4">
              <form action="{{ route('post.comment.store') }}" method="post">
                  @csrf

                  <input
                      type="text"
                      class="form-control"
                      placeholder="Type comment..."
                      name="comment"
                  />

                  <input type="hidden" name="post_id" value="{{ $post->id }}">
                  <input type="hidden" name="user_id" value="{{ $post->user_id }}">
                  <input type="submit" hidden/>
              </form>
          </div>
        @endauth

        @guest
          <h3>Login to comment on post !!</h3>
        @endguest

        <div class="card mb-4">
            @foreach($comments as $comment)
                <div class="card-body mb-2" style="border: 1px solid grey;">
                    <p>{{ $comment->body }}</p>

                    <div class="d-flex justify-content-between">
                    <div class="d-flex flex-row align-items-center">
                        <i class="fa fa-user-circle-o"></i>
                        <p class="small mb-0 ms-2">{{ $comment->user->username }}</p>
                    </div>
                    </div>
                </div>
            @endforeach

        </div>
      </div>
    <!-- </div> -->
  </div>
</div>