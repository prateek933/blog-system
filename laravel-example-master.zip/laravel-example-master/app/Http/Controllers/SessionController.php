<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use Session;

class SessionController extends Controller
{
     /**
     * Show the user login form.
     *
     * @return \Illuminate\View\View
     */
    public function show()
    {
        return view('user.login');
    }

    /**
     * Create login session using auth attempt
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $this->validate(request(), [
            'email' => 'required|email',
            'password' => 'required|min:6'
        ]);

        $userData = array(
            'email'  => request('email'),
            'password' => request('password')
        );

        if(Auth::attempt($userData)) {
            session()->flash('message', 'Login Successfully');

            return redirect()->route('user.posts.index');
        } else {
            session()->flash('message', 'something went wrong !');

            return redirect()->back();
        }
    }

     /**
     * Remove the specified resource from storage.
     *
     * @return \Illuminate\Http\Response
     */
    public function destroy()
    {
        Session::flush();

        Auth::logout();

        return redirect()->route('user.session.index');
    }
}