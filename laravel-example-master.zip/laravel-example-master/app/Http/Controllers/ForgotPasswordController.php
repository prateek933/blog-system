<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Mail;
use App\Mail\ResetPassword;
use App\Models\User;

class ForgotPasswordController extends Controller
{
    public function index()
    {
        return view('user.forgot-password');
    }

    public function store()
    {
        $user = User::where('email', request('email'))->get()->toArray();

        if (empty($user)) {
            abort(404);
        }

        try {
            Mail::queue(new ResetPassword(['email' => request('email'), 'token' => request('_token')]));

            session()->flash('message', 'Mail sent successfully');

            return redirect()->back();
        } catch(\Exception $e) {}
    }

    public function showResetPassword($email)
    {
        return view('user.reset-password-form')->with('email', $email);
    }

    public function resetPassword()
    {
        $email = request('email');
        $password = request('new_password');

        $user->update(['password' => bcrypt($password)]);

        session()->flash('message', 'Password updated');

        return redirect()->route('user.session.index');
    }
}
