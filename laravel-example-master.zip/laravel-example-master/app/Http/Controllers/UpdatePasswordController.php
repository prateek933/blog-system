<?php

namespace App\Http\Controllers;

use App\Models\User;

class UpdatePasswordController extends Controller
{
    public function index()
    {
        return view('user.change-password');
    }

    public function store()
    {
        $user = User::where('email', '=', auth()->user()->email)->first();

        $matchPassword = \Hash::check(request('old_password'), $user->password);

        if ($matchPassword) {
            $user->update(['password' => bcrypt(request('new_password'))]);
        } else {
            session()->flash('message', 'Invalid credentials');

            return redirect()->back();
        }
    }
}
