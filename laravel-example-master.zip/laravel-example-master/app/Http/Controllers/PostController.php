<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Post;

class PostController extends Controller
{
    /**
     * Displays the post form and list of posts
     *
     * @return \Illuminate\View\view
     */
    public function index()
    {
        $posts = Post::where('user_id', auth()->user()->id)->simplePaginate('10');

        return view('user.post.index')->with('posts', $posts);
    }


    public function store()
    {
        $this->validate(request(), [
            'title_name' => 'required',
            'content' => 'required',
            'tags' => 'required',
        ]);

        Post::Create([
            'title'=> request('title_name'),
            'description'=> request('content'),
            'user_id' => auth()->user()->id,
            'author'=> auth()->user()->username,
            'tagnames'=> request('tags')
        ]);

        session()->flash('message', 'Post created');

        return redirect()->back();
    }

    public function deletePost($id)
    {
        $post = Post::find($id);
        $post->delete();

        session()->flash('message', 'Post deleted');

        return redirect()->back();
    }

    /**
     * Store comments related to post
     */
    public function storeComments()
    {
        $this->validate(request(), [
            'comment' => 'required'
        ]);

        app('App\Models\Comment')->create([
            'user_id' => request('user_id'),
            'post_id' => request('post_id'),
            'body' => request('comment'),
        ]);

        session()->flash('message', 'Added Comment');

        return redirect()->back();
    }
}
