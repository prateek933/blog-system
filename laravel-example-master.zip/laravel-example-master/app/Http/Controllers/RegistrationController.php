<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;

class RegistrationController extends Controller
{
     /**
     * Show the user signup form.
     *
     * @return \Illuminate\View\View
     */
    public function show()
    {
        return view('user.signup');
    }

    /**
     * Store the user resource
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $this->validate(request(), [
            'username' => 'required',
            'email' => 'required|email|unique:users,email',
            'password' => 'required|min:6'
        ]);

        User::create([
            'username' => request('username'),
            'email' => request('email'),
            'password' => bcrypt(request('password')),
        ]);

        session()->flash('message', 'User Registered Successfully');

        return redirect()->route('user.session.index');
    }
}
