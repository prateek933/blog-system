<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Post;
use App\Models\Comment;


class HomeController extends Controller
{
    /**
     * Display listing of resource
     *
     * @return \Illuminate\View\view
     */
    public function index()
    {
        $posts = Post::orderBy('created_at', 'desc')->simplePaginate(2);

        return view('home.index')->with('posts', $posts);
    }

    /**
     * Show post with comments
     *
     * @return \Illuminate\View\view
     */
    public function showPost($id)
    {
        $post = Post::find($id);
        $comments = $post->comments()->get();

        return view('home.view-post')->with('post', $post)->with('comments', $comments);
    }

    /**
     * Load the view with serach result
     *
     * @return \Illuminate\View\view
     */
    public function search()
    {
        $search = request('search');

        $posts = Post::orderBy('id', 'desc')
                 ->where('title', 'lIKE', '%'.$search.'%')
                 ->orWhere('description', 'lIKE', '%'.$search.'%')
                 ->orWhere('tagnames', 'lIKE', '%'.$search.'%')
                 ->simplePaginate(2);

        return view('home.index')->with('posts', $posts);
    }
}
