# Simple Blog System

### Technologies stack:

-   **SERVER**: Apache 2.
-   **PHP**: 7.4 or higher.
-   **For MySQL users**: 5.7.23 or higher.
-   **Node**: 8.11.3 LTS or higher.
-   **Composer**: 1.6.5 or higher.
-   **CSS**
-   **Javascript**
-   **Bootstrap**
-   **Laravel**: 8.83.1

### Installation and Configuration

**1. You can install project Git clone**

##### Execute these commands below, in order

```
composer create-project
```

-   Enter the mail and database credentials within .env file in your project root directory.
    Note: You may use database name as **example** and use the example.sql file for dummy data.

```
composer dump-autoload

```

```
composer dump-autoload
php artisan optimize:clear
php artisan route:clear
php artisan migrate (If not using sql file, import)
```

#### Pending and can be Enhance

In future, can add the dynamic text instead of static text with the use of laravel trans. And, can make project available in locale wise. Can enhance in terms of UI using bootstrap defined components and can add VueJS for reactivity and component wise structure.

### User login Credentials

johndoe@blogger.com/123456
